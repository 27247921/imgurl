<?php
/**
 * Http客户端异常类
 *
 * @package Http
 */
class _Http_Client_Exception
{
public function __construct($msg,$error){
//echo $msg;
exit;
}
}
